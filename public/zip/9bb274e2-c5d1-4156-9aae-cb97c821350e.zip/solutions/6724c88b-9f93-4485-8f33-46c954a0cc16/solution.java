public class HolaMundo {
    public static void  main(String[] args) {
        System.out.println("MODULO DE PROGRAMACION");
        System.out.println("Hola a tod@s");
    }
}